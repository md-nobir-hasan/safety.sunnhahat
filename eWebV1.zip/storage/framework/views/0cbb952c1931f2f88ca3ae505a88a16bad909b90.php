<?php $__env->startSection('title', 'Order Management'); ?>

<?php $__env->startPush('third_party_stylesheets'); ?>
    <link href="<?php echo e(asset('assets/backend/js/DataTable/datatables.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('page_css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-10 col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <span class="float-left">
                            <h4>View Order</h4>
                        </span>
                        <span class="float-right">
                            <a href="<?php echo e(route('order.index')); ?>" class="btn btn-info">Back</a>
                        </span>
                    </div>
                    <div class="card-body">
                        <?php echo $__env->make('backend.partial.flush-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <div class="table table-responsive">
                            <table id="table" class="table-responsive">
                                <thead>
                                    <tr>
                                        <th>S.N.</th>
                                        <th>Order No.</th>
                                        <th>Name</th>
                                        <th>phone</th>
                                        <th>Email</th>
                                        <th>Quantity</th>
                                        <th>Shiping Charge</th>
                                        <th>Total Amount</th>
                                        <th>Payment Number</th>
                                        <th>Payment Method</th>
                                        <th>Ordered Time</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($key + 1); ?></td>
                                            <td><?php echo e($order->order_number); ?></td>
                                            <td><?php echo e($order->first_name); ?></td>
                                            <td><?php echo e($order->phone); ?></td>
                                            <td><?php echo e($order->email); ?></td>
                                            <td><?php echo e($order->quantity); ?></td>
                                            <td><?php echo e($order->shipping->price); ?></td>
                                            <td>TK<?php echo e(number_format($order->total_amount, 2)); ?>

                                            </td>
                                            <td><?php echo e($order->payment_number); ?></td>
                                            <td><?php echo e($order->pamyment_methods); ?></td>
                                            <td><?php echo e($order->created_at->diffForHumans()); ?></td>
                                            <td>
                                                <?php if($order->order_status == 'new'): ?>
                                                    <span class="badge badge-primary"><?php echo e($order->order_status); ?></span>
                                                <?php elseif($order->order_status == 'process'): ?>
                                                    <span class="badge badge-warning"><?php echo e($order->order_status); ?></span>
                                                <?php elseif($order->order_status == 'delivered'): ?>
                                                    <span class="badge badge-success"><?php echo e($order->order_status); ?></span>
                                                <?php else: ?>
                                                    <span class="badge badge-danger"><?php echo e($order->order_status); ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-middle py-0 align-middle">
                                                <div class="btn-group">
                                                    <a href="<?php echo e(route('order.restore', $order->id)); ?>"
                                                        class="btn btn-dark btnEdit" title="Restore"><i
                                                            class="fas fa-trash-restore">Restore</i></a>
                                                    <a title="Permanently delete"
                                                        href="<?php echo e(route('order.destroy', $order->id)); ?>"
                                                        class="btn btn-danger btnDelete"><i
                                                            class="fas fa-trash">Delete</i></a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('third_party_scripts'); ?>
    <script src="<?php echo e(asset('assets/backend/js/DataTable/datatables.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('page_scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#table').DataTable({
                dom: 'Bfrtip',
                buttons: [{
                        extend: 'pdfHtml5',
                        title: 'District Management',
                        download: 'open',
                        orientation: 'potrait',
                        pagesize: 'LETTER',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
                        }
                    },
                    {
                        extend: 'print',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
                        }
                    }, 'pageLength'
                ]
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH N:\projects\eWebV1\resources\views/backend/pages/order/trash.blade.php ENDPATH**/ ?>