<li class="nav-item">
    <a href="<?php echo e(route('admin')); ?>" class="nav-link <?php echo e(Request::is('home') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-home"></i>
        <p>Home</p>
    </a>
</li>


<li class="nav-item <?php echo e(Request::is('category/*') ? 'menu-open' : ''); ?>">
    <a href="#" class="nav-link">
        <i class="nav-icon fas fa-users"></i>
        <p>
            Category
            <i class="fas fa-angle-left right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="<?php echo e(route('category.index')); ?>"
                class="nav-link <?php echo e(Request::is('category/index') ? 'active' : ''); ?>">
                <i class="nav-icon far fa-circle"></i>
                <p>Show Category</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('category.create')); ?>"
                class="nav-link <?php echo e(Request::is('category/create') ? 'active' : ''); ?>">
                <i class="nav-icon far fa-circle"></i>
                <p>Add Category</p>
            </a>
        </li>
    </ul>
</li>


<li class="nav-item <?php echo e(Request::is('shipping/*') ? 'menu-open' : ''); ?>">
    <a href="#" class="nav-link">
        <i class="nav-icon fas fa-users"></i>
        <p>
            Shipping
            <i class="fas fa-angle-left right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="<?php echo e(route('shipping.index')); ?>"
                class="nav-link <?php echo e(Request::is('shipping/index') ? 'active' : ''); ?>">
                <i class="nav-icon far fa-circle"></i>
                <p>Show Shipping</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('shipping.create')); ?>"
                class="nav-link <?php echo e(Request::is('shipping/create') ? 'active' : ''); ?>">
                <i class="nav-icon far fa-circle"></i>
                <p>Add Shipping</p>
            </a>
        </li>
    </ul>
</li>


<li class="nav-item <?php echo e(Request::is('brand/*') ? 'menu-open' : ''); ?>">
    <a href="#" class="nav-link">
        <i class="nav-icon fas fa-users"></i>
        <p>
            Brand
            <i class="fas fa-angle-left right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="<?php echo e(route('brand.index')); ?>" class="nav-link <?php echo e(Request::is('brand/index') ? 'active' : ''); ?>">
                <i class="nav-icon far fa-circle"></i>
                <p>Show Brand</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('brand.create')); ?>" class="nav-link <?php echo e(Request::is('brand/create') ? 'active' : ''); ?>">
                <i class="nav-icon far fa-circle"></i>
                <p>Add Brand</p>
            </a>
        </li>
    </ul>
</li>


<li class="nav-item <?php echo e(Request::is('product/*') ? 'menu-open' : ''); ?>">
    <a href="#" class="nav-link">
        <i class="nav-icon fas fa-users"></i>
        <p>
            Product
            <i class="fas fa-angle-left right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="<?php echo e(route('product.index')); ?>"
                class="nav-link <?php echo e(Request::is('product/index') ? 'active' : ''); ?>">
                <i class="nav-icon far fa-circle"></i>
                <p>Show Product</p>
            </a>
        </li>
        <?php if(Auth::user()->roll == 'super_admin'): ?>
            <li class="nav-item">
                <a href="<?php echo e(route('product.create')); ?>"
                    class="nav-link <?php echo e(Request::is('product/create') ? 'active' : ''); ?>">
                    <i class="nav-icon far fa-circle"></i>
                    <p>Add Product</p>
                </a>
            </li>
        <?php endif; ?>
    </ul>
</li>



<li class="nav-item <?php echo e(Request::is('order/*') ? 'menu-open' : ''); ?>">
    <a href="#" class="nav-link">
        <i class="nav-icon fas fa-users"></i>
        <p>
            Order
            <i class="fas fa-angle-left right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="<?php echo e(route('order.index')); ?>" class="nav-link <?php echo e(Request::is('order/index') ? 'active' : ''); ?>">
                <i class="nav-icon far fa-circle"></i>
                <p>Show Order</p>
            </a>
        </li>
    </ul>
</li>


<?php if(Auth::user()->roll == 'super_admin'): ?>
    <li class="nav-item <?php echo e(Request::is('order-status/*') ? 'menu-open' : ''); ?>">
        <a href="#" class="nav-link">
            <i class="nav-icon fas fa-users"></i>
            <p>
                Order Status
                <i class="fas fa-angle-left right"></i>
            </p>
        </a>
        <ul class="nav nav-treeview">
            <li class="nav-item">
                <a href="<?php echo e(route('order-status.index')); ?>"
                    class="nav-link <?php echo e(Request::is('order/index') ? 'active' : ''); ?>">
                    <i class="nav-icon far fa-circle"></i>
                    <p>Show Order status</p>
                </a>
            </li>
        </ul>
        <ul class="nav nav-treeview">
            <li class="nav-item">
                <a href="<?php echo e(route('order-status.create')); ?>"
                    class="nav-link <?php echo e(Request::is('order/index') ? 'active' : ''); ?>">
                    <i class="nav-icon far fa-plus"></i>
                    <p>Add Order status</p>
                </a>
            </li>
        </ul>
    </li>
<?php endif; ?>
<?php /**PATH N:\projects\eWebV1\resources\views/backend/partial/menu.blade.php ENDPATH**/ ?>